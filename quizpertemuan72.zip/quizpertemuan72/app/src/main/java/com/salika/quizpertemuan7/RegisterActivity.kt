package com.salika.quizpertemuan7

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject

class RegisterActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

        val nama = findViewById<EditText>(R.id.etNama)
        val email = findViewById<EditText>(R.id.etEmail)
        val password = findViewById<EditText>(R.id.etPassword)
        val konfirmasi = findViewById<EditText>(R.id.etKonfirmasi)
        val btnDaftar = findViewById<Button>(R.id.btnDaftar)
        val tvLogin = findViewById<TextView>(R.id.tvLogin)

        btnDaftar.setOnClickListener {
            val n = nama.text.toString().trim()
            val e = email.text.toString().trim()
            val p = password.text.toString()
            val k = konfirmasi.text.toString()

            if (n.isEmpty() || e.isEmpty() || p.isEmpty()) {
                Toast.makeText(
                    this, "Semua data wajib diisi",
                    Toast.LENGTH_SHORT
                ).show()
                return@setOnClickListener
            }

            if (p.length < 8) {
                Toast.makeText(
                    this, "Password minimal 8 karakter",
                    Toast.LENGTH_SHORT
                ).show()
                return@setOnClickListener
            }

            if (p != k) {
                Toast.makeText(
                    this, "Konfirmasi password tidak sama",
                    Toast.LENGTH_SHORT
                ).show()
                return@setOnClickListener
            }

            btnDaftar.isEnabled = false

            val data = JSONObject().apply {
                put("nama", n)
                put("email", e)
                put("password", p)
            }

            ApiClient.post("register.php", data) {
                    success, message, _ ->
                runOnUiThread {
                    btnDaftar.isEnabled = true

                    Toast.makeText(
                        this, message, Toast.LENGTH_SHORT
                    ).show()

                    if (success) {
                        startActivity(
                            Intent(this, MainActivity::class.java)
                        )
                        finish()
                    }
                }
            }
        }

        tvLogin.setOnClickListener {
            finish()
        }
    }
}
